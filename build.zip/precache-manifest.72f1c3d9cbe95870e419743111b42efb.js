self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e01348d49f7d14840759df0ee7b965f8",
    "url": "./index.html"
  },
  {
    "revision": "3bea19c052fdd9554b3a",
    "url": "./static/css/main.a3e2ead0.chunk.css"
  },
  {
    "revision": "441c8e17a34a22854d91",
    "url": "./static/js/2.d4b26ebc.chunk.js"
  },
  {
    "revision": "3bea19c052fdd9554b3a",
    "url": "./static/js/main.3538f20a.chunk.js"
  },
  {
    "revision": "8c97409f0ee389fe75da",
    "url": "./static/js/runtime-main.d653cc00.js"
  },
  {
    "revision": "426ffaa244aebbed4932c90e62380151",
    "url": "./static/media/1-fala1.426ffaa2.svg"
  },
  {
    "revision": "09c5f6a26af7a4888d79c83d15f51707",
    "url": "./static/media/1-fala2.09c5f6a2.svg"
  },
  {
    "revision": "4d1bcc53ae5c295049544e17a5d3fd39",
    "url": "./static/media/1-fala3.4d1bcc53.svg"
  },
  {
    "revision": "882d34369e96db2e63f6047e47657b37",
    "url": "./static/media/2-fala1.882d3436.svg"
  },
  {
    "revision": "b67d452e14af0010ac49aa2479d87343",
    "url": "./static/media/2-fala2.b67d452e.svg"
  },
  {
    "revision": "f32ba4676868b4fd1bb8685616041395",
    "url": "./static/media/2-fala3.f32ba467.svg"
  },
  {
    "revision": "8b1dac282dbd740938a37242aa4bed1a",
    "url": "./static/media/3-fala1.8b1dac28.svg"
  },
  {
    "revision": "dd434cd7e7ee08cf73818cebf9006c69",
    "url": "./static/media/3-fala2.dd434cd7.svg"
  },
  {
    "revision": "52ec8b0456d1a9bdb5ffa738504e9e44",
    "url": "./static/media/3-fala3.52ec8b04.svg"
  },
  {
    "revision": "34f97f1c35e7d0d06aa7f3e400843cd9",
    "url": "./static/media/4-fala1.34f97f1c.svg"
  },
  {
    "revision": "99b26dd5040e3d47180f7259008ac970",
    "url": "./static/media/4-fala2.99b26dd5.svg"
  },
  {
    "revision": "1d2053d4d9801eb3ba4457e3abe44094",
    "url": "./static/media/4-fala3.1d2053d4.svg"
  },
  {
    "revision": "5cc7e91312d27bf925cb4fbc90ffaa22",
    "url": "./static/media/5-fala1.5cc7e913.svg"
  },
  {
    "revision": "66cc1ac0e09062ce735fb4037de6d76c",
    "url": "./static/media/5-fala2.66cc1ac0.svg"
  },
  {
    "revision": "ed91d32ce5a19613ee010396bd8b3b23",
    "url": "./static/media/5-fala3.ed91d32c.svg"
  },
  {
    "revision": "0318792cb767ef36769a4d7355094fef",
    "url": "./static/media/6-fala1.0318792c.svg"
  },
  {
    "revision": "8d2e0a4907ad1a3ca0a6c1f8b240e8ef",
    "url": "./static/media/6-fala2.8d2e0a49.svg"
  },
  {
    "revision": "5543ad3660bd3ed5c48c4bb8a2cb8ff4",
    "url": "./static/media/Bairro.5543ad36.svg"
  },
  {
    "revision": "3dc3988dbb57392760c92df8db373c4e",
    "url": "./static/media/CaixaTextoIntro.3dc3988d.svg"
  },
  {
    "revision": "6890660b041e88bb1ddaba01847e535d",
    "url": "./static/media/Familia.6890660b.svg"
  },
  {
    "revision": "6fdde780aa0a51eef53afa420f669f3b",
    "url": "./static/media/Feira.6fdde780.svg"
  },
  {
    "revision": "7465215bcd77364b953a222d11ecea87",
    "url": "./static/media/I1-pilares.7465215b.svg"
  },
  {
    "revision": "dbaddf51db030772bf36b489ee4b6abe",
    "url": "./static/media/anotacao.dbaddf51.svg"
  },
  {
    "revision": "7bf0d5a5a3d2c96c64331165bcdb6a0f",
    "url": "./static/media/background.7bf0d5a5.svg"
  },
  {
    "revision": "4adce44188a62b6fbac84f0b5dfab312",
    "url": "./static/media/caixatextopg3.4adce441.svg"
  },
  {
    "revision": "b2627f417ef63ac854645015fc73dbc7",
    "url": "./static/media/caixatextopg4.b2627f41.svg"
  },
  {
    "revision": "be924c68c2e59b60b96d5739326d81e9",
    "url": "./static/media/estrela.be924c68.svg"
  },
  {
    "revision": "d023c58d636b1eb02ce236d736d5de1c",
    "url": "./static/media/logo.d023c58d.svg"
  },
  {
    "revision": "c2212a2fcb0b9b275ba2cadf1a025abc",
    "url": "./static/media/micromundo3pg3.c2212a2f.svg"
  },
  {
    "revision": "5743a07fe48ad3373576baa4434789ed",
    "url": "./static/media/micromundo3pg7.5743a07f.svg"
  },
  {
    "revision": "76d97c38641d4ab64cdbf3e28f5ce866",
    "url": "./static/media/micromundo4pg10-1.76d97c38.svg"
  },
  {
    "revision": "6988be3f773222c7aa105f9ce6028bb9",
    "url": "./static/media/micromundo4pg10-2.6988be3f.svg"
  },
  {
    "revision": "25b157bad0de67adebffaf1da55e21e0",
    "url": "./static/media/micromundo4pg2.25b157ba.svg"
  },
  {
    "revision": "4c79a9c1befa9258795f2e85994de69c",
    "url": "./static/media/micromundo4pg3.4c79a9c1.svg"
  },
  {
    "revision": "fadd9d4533a0114c397ede3e039de846",
    "url": "./static/media/micromundo4pg9.fadd9d45.svg"
  },
  {
    "revision": "30cc7bb2b927582dad8770aa318a98c9",
    "url": "./static/media/olimpiada.30cc7bb2.svg"
  },
  {
    "revision": "1a1193d42c89fe81cafb6ff94387b149",
    "url": "./static/media/slide-2.1a1193d4.svg"
  },
  {
    "revision": "4fcb4346665a06ed4931072d1ad711ac",
    "url": "./static/media/slide-2.4fcb4346.svg"
  },
  {
    "revision": "b40f1dae74ce740708653493f0760458",
    "url": "./static/media/slide-6.b40f1dae.svg"
  },
  {
    "revision": "aecc78e93af336b035acdff8f8722816",
    "url": "./static/media/top.aecc78e9.svg"
  }
]);