self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "30c80af2a03b78772148437b7dcfc4fb",
    "url": "./index.html"
  },
  {
    "revision": "c980c0f5e30f34099f38",
    "url": "./static/css/main.c5cc028c.chunk.css"
  },
  {
    "revision": "e85cae601a655ea5c8b7",
    "url": "./static/js/2.d792a461.chunk.js"
  },
  {
    "revision": "c980c0f5e30f34099f38",
    "url": "./static/js/main.a1093f5c.chunk.js"
  },
  {
    "revision": "8c97409f0ee389fe75da",
    "url": "./static/js/runtime-main.d653cc00.js"
  },
  {
    "revision": "426ffaa244aebbed4932c90e62380151",
    "url": "./static/media/1-fala1.426ffaa2.svg"
  },
  {
    "revision": "09c5f6a26af7a4888d79c83d15f51707",
    "url": "./static/media/1-fala2.09c5f6a2.svg"
  },
  {
    "revision": "4d1bcc53ae5c295049544e17a5d3fd39",
    "url": "./static/media/1-fala3.4d1bcc53.svg"
  },
  {
    "revision": "882d34369e96db2e63f6047e47657b37",
    "url": "./static/media/2-fala1.882d3436.svg"
  },
  {
    "revision": "b67d452e14af0010ac49aa2479d87343",
    "url": "./static/media/2-fala2.b67d452e.svg"
  },
  {
    "revision": "f32ba4676868b4fd1bb8685616041395",
    "url": "./static/media/2-fala3.f32ba467.svg"
  },
  {
    "revision": "8b1dac282dbd740938a37242aa4bed1a",
    "url": "./static/media/3-fala1.8b1dac28.svg"
  },
  {
    "revision": "dd434cd7e7ee08cf73818cebf9006c69",
    "url": "./static/media/3-fala2.dd434cd7.svg"
  },
  {
    "revision": "52ec8b0456d1a9bdb5ffa738504e9e44",
    "url": "./static/media/3-fala3.52ec8b04.svg"
  },
  {
    "revision": "34f97f1c35e7d0d06aa7f3e400843cd9",
    "url": "./static/media/4-fala1.34f97f1c.svg"
  },
  {
    "revision": "99b26dd5040e3d47180f7259008ac970",
    "url": "./static/media/4-fala2.99b26dd5.svg"
  },
  {
    "revision": "1d2053d4d9801eb3ba4457e3abe44094",
    "url": "./static/media/4-fala3.1d2053d4.svg"
  },
  {
    "revision": "0318792cb767ef36769a4d7355094fef",
    "url": "./static/media/6-fala1.0318792c.svg"
  },
  {
    "revision": "8d2e0a4907ad1a3ca0a6c1f8b240e8ef",
    "url": "./static/media/6-fala2.8d2e0a49.svg"
  },
  {
    "revision": "5543ad3660bd3ed5c48c4bb8a2cb8ff4",
    "url": "./static/media/Bairro.5543ad36.svg"
  },
  {
    "revision": "0affc3c2c1c2a475c68179246aa4d71c",
    "url": "./static/media/CaixaTextoIntro.0affc3c2.svg"
  },
  {
    "revision": "6890660b041e88bb1ddaba01847e535d",
    "url": "./static/media/Familia.6890660b.svg"
  },
  {
    "revision": "6fdde780aa0a51eef53afa420f669f3b",
    "url": "./static/media/Feira.6fdde780.svg"
  },
  {
    "revision": "7465215bcd77364b953a222d11ecea87",
    "url": "./static/media/I1-pilares.7465215b.svg"
  },
  {
    "revision": "dbaddf51db030772bf36b489ee4b6abe",
    "url": "./static/media/anotacao.dbaddf51.svg"
  },
  {
    "revision": "7bf0d5a5a3d2c96c64331165bcdb6a0f",
    "url": "./static/media/background.7bf0d5a5.svg"
  },
  {
    "revision": "be924c68c2e59b60b96d5739326d81e9",
    "url": "./static/media/estrela.be924c68.svg"
  },
  {
    "revision": "d023c58d636b1eb02ce236d736d5de1c",
    "url": "./static/media/logo.d023c58d.svg"
  },
  {
    "revision": "4580abaed048c2a4f7e02f76bf528a5b",
    "url": "./static/media/micromundo3pg3.4580abae.svg"
  },
  {
    "revision": "8ce3f56d624847a4df2303d8adf98874",
    "url": "./static/media/micromundo3pg7.8ce3f56d.svg"
  },
  {
    "revision": "e6e3e6a3e8e0c296136bae603e41dd33",
    "url": "./static/media/micromundo4pg10-1.e6e3e6a3.svg"
  },
  {
    "revision": "6988be3f773222c7aa105f9ce6028bb9",
    "url": "./static/media/micromundo4pg10-2.6988be3f.svg"
  },
  {
    "revision": "f90593310bf24778d0b931113ca7959d",
    "url": "./static/media/micromundo4pg2.f9059331.svg"
  },
  {
    "revision": "4facd3f77d90f64a064fd46e8b190f5a",
    "url": "./static/media/micromundo4pg3.4facd3f7.svg"
  },
  {
    "revision": "30cc7bb2b927582dad8770aa318a98c9",
    "url": "./static/media/olimpiada.30cc7bb2.svg"
  },
  {
    "revision": "68d33a897037fe333c2f38fc25b97715",
    "url": "./static/media/slide-2.68d33a89.svg"
  },
  {
    "revision": "af4e18e59c0922ab43adfe45f75fd3e2",
    "url": "./static/media/slide-2.af4e18e5.svg"
  },
  {
    "revision": "6837cf6e73f3b17c13e7edad4428d48a",
    "url": "./static/media/slide-6.6837cf6e.svg"
  },
  {
    "revision": "aecc78e93af336b035acdff8f8722816",
    "url": "./static/media/top.aecc78e9.svg"
  }
]);